from abc import ABC, abstractmethod
class Animal(ABC):
    @abstractmethod
    def sound(self):
        print("This animal is eating.")
class Dog(Animal):
    def sound(self):
        return "Woof"
    def eat(self):
        print("This dog is eating its food.")
class Cat(Animal):
    def sound(self):
        return "Meow"
    def eat(self):
        print("The cat is eating its food.")
dog = Dog()
cat = Cat()
print(dog.sound())
dog.eat()
print(cat.sound())
cat.eat()
    
