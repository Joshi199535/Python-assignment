from abc import ABC, abstractmethod
class Animal(ABC):
    @abstractmethod
    def sound(self):
        pass
    def eat(self):
        print("This animal is eating.")
class Dog(Animal):
    def sound(self):
        return "Woof"
    def eat(self):
        print("The dog is eating its food.")
dog = Dog()
dog.eat()
print(dog.sound())
