from abc import ABC, abstractmethod
class Animal(ABC):
    @abstractmethod
    def sound(self):
        pass
    def eat(self):
        print("This animal is eating.")
class Dog(Animal):
    def sound(self):
        return "Woof"
    @staticmethod
    def create_instance_and_call_non_abstract_methods():
        dog_instance = Dog()
        dog_instance.eat()
Dog.create_instance_and_call_non_abstract_methods()
