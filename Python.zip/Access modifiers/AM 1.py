# Parent class with private fields and a private method
class Person:
    def __init__(self, name, age):
        # Private fields
        self.__name = name
        self.__age = age
    
    # Private method
    def __private_method(self):
        print("This is a private method.")
    
    # Public method to access private fields
    def display_info(self):
        print(f"Name: {self.__name}, Age: {self.__age}")
    
    # Public method to call the private method
    def call_private_method(self):
        self.__private_method()

# Subclass inheriting from Person
class Employee(Person):
    def __init__(self, name, age, job_title):
        # Call the constructor of the parent class
        super().__init__(name, age)
        self.job_title = job_title
    
    # Trying to access private fields and methods of the parent class
    def try_access_private_fields(self):
        # Cannot directly access private fields __name and __age
        # print(self.__name)  # This will raise an error
        # print(self.__age)   # This will raise an error

        # However, the private fields are accessible via the parent class' public method
        self.display_info()

    def try_call_private_method(self):
        # Cannot directly call private method __private_method
        # self.__private_method()  # This will raise an error
        
        # Can access the private method via a public method
        self.call_private_method()

# Main function to demonstrate the access control
def main():
    # Create a Person object
    person = Person("Alice", 30)
    
    # Accessing private fields via public method
    person.display_info()
    
    # Calling the private method via public method
    person.call_private_method()
    
    print("\nCreating an Employee object and trying to access private fields and methods:")

    # Create an Employee object
    employee = Employee("Bob", 40, "Engineer")
    
    # Trying to access private fields and methods from the subclass
    employee.try_access_private_fields()  # This will use the public method from the parent class
    employee.try_call_private_method()   # This will use the public method from the parent class

# Call the main function
if __name__ == "__main__":
    main()
