# parent.py
class Person:
    def __init__(self, name, age):
        # Protected fields
        self._name = name
        self._age = age

    # Protected method
    def _display_info(self):
        print(f"Name: {self._name}, Age: {self._age}")

# child.py
from package1.parent import Person

class Employee(Person):
    def __init__(self, name, age, job_title):
        super().__init__(name, age)
        self._job_title = job_title

    def display_employee_info(self):
        # Accessing protected fields and methods from the parent class
        print(f"Employee Info: {self._name}, {self._age}, {self._job_title}")
        self._display_info()  # Calling the protected method from parent

# Create an Employee object and display info
emp = Employee("Alice", 30, "Engineer")
emp.display_employee_info()

# another_child.py
from package1.child import Employee

class Manager(Employee):
    def __init__(self, name, age, job_title, department):
        super().__init__(name, age, job_title)
        self._department = department

    def display_manager_info(self):
        # Accessing protected fields from the parent class (via Employee)
        print(f"Manager Info: {self._name}, {self._age}, {self._job_title}, {self._department}")
        self._display_info()  # Calling the protected method from Employee

# Create a Manager object and display info
mgr = Manager("Bob", 40, "Manager", "HR")
mgr.display_manager_info()

# main.py
from package2.another_child import Manager

# Create a Manager object and display manager info
manager = Manager("Charlie", 45, "Director", "Sales")
manager.display_manager_info()

