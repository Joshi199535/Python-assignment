# In package1/public_class.py
class PublicClass:
    def __init__(self, public_field1, public_field2):
        self.public_field1 = public_field1
        self.public_field2 = public_field2

    def public_method(self):
        print("This is a public method.")

# In package1/access_from_same_package.py
from .public_class import PublicClass

class AccessFromSamePackage:
    def access_public_members(self, public_obj):
        print(public_obj.public_field1)
        print(public_obj.public_field2)
        public_obj.public_method()

# In package2/access_from_different_package.py
from package1.public_class import PublicClass

class AccessFromDifferentPackage:
    def access_public_members(self, public_obj):
        print(public_obj.public_field1)
        print(public_obj.public_field2)
        public_obj.public_method()
