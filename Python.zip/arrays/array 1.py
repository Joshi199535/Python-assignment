def sum_array(arr):
    """
    Sums up the integer values in an array.

    Parameters:
        arr (list): A list of integers.

    Returns:
        int: The sum of the integers in the array.
    """
    if not all(isinstance(i, int) for i in arr):
        raise ValueError("All elements in the array must be integers.")
    
    return sum(arr)

# Example usage:
array = [1, 2, 3, 4, 5]
result = sum_array(array)
print("The sum of the array is:", result)
