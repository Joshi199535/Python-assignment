def find_duplicates(arr):
    duplicates = []
    seen = set()
    for value in arr:
        if value in seen and value not in duplicates:
            duplicates.append(value)
        else:
            seen.add(value)
    return duplicates
arr = [10, 20, 30, 20, 40, 50, 30, 10]
duplicates = find_duplicates(arr)

print(f"Duplicate values: {duplicates}")

