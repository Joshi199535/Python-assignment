def find_common_elements(arr1, arr2):
    return list(set(arr1) & set(arr2))
arr1 = [10, 20, 30, 40, 50]
arr2 = [30, 40, 60, 70, 80]
common_elements = find_common_elements(arr1, arr2)

print(f"Common values: {common_elements}")

