def remove_duplicates(arr):
    return list(set(arr))
arr = [10, 20, 30, 20, 40, 50, 30, 10]
unique_array = remove_duplicates(arr)

print(f"Array with duplicates removed: {unique_array}")
def remove_duplicates_ordered(arr):
    seen = set()
    result = []
    for value in arr:
        if value not in seen:
            result.append(value)
            seen.add(value)
    return result


