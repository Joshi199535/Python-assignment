def second_largest(arr):
    if len(arr) < 2:
        return None  # Return None if there are fewer than 2 elements

    # Remove duplicates by converting to a set, then sort in descending order
    unique_arr = list(set(arr))
    unique_arr.sort(reverse=True)

    return unique_arr[1] if len(unique_arr) > 1 else None  # Return the second largest, or None if not available
arr = [10, 20, 30, 40, 50, 30, 10]
result = second_largest(arr)

print(f"The second largest number is: {result}")
