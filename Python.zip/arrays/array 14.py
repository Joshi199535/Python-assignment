def second_largest(arr):
    if len(arr) < 2:
        return None  # Return None if there are fewer than 2 elements

    first, second = float('-inf'), float('-inf')  # Initialize to negative infinity

    for num in arr:
        if num > first:
            second = first  # Update second largest before first largest
            first = num  # Update first largest
        elif num > second and num != first:
            second = num  # Update second largest if the number is smaller than first but larger than second

    return second if second != float('-inf') else None  # Return None if no second largest exists
arr = [10, 20, 30, 40, 50, 30, 10]
result = second_largest(arr)

print(f"The second largest number is: {result}")
