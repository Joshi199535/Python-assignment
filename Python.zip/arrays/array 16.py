def difference_largest_smallest(arr):
    if len(arr) == 0:
        return None  # Return None if the array is empty
    return max(arr) - min(arr)
arr = [10, 20, 30, 40, 50]
result = difference_largest_smallest(arr)

print(f"The difference between the largest and smallest value is: {result}")

