def contains_specified_elements(arr, elem1, elem2):
    return elem1 in arr and elem2 in arr
arr = [10, 12, 23, 30, 40]
result = contains_specified_elements(arr, 12, 23)

if result:
    print("Array contains both 12 and 23.")
else:
    print("Array does not contain both 12 and 23.")

