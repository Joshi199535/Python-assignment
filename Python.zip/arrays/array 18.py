def remove_duplicates(arr):
    return list(set(arr))  # Converts array to a set and then back to a list
arr = [10, 20, 30, 20, 40, 50, 30, 10]
new_array = remove_duplicates(arr)

print(f"Array with duplicates removed: {new_array}")
