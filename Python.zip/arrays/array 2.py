def average_of_array(arr):
    if len(arr) == 0:
        return 0  # Return 0 to handle empty array case
    return sum(arr) / len(arr)
arr = [10, 20, 30, 40, 50]
result = average_of_array(arr)
print(f"The average is: {result}")  # Output will be: The average is: 30.0

