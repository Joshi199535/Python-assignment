def find_index(arr, element):
    try:
        index = arr.index(element)  # Use the index() method
        return index
    except ValueError:
        return -1  # Return -1 if the element is not found

arr = [10, 20, 30, 40, 50]
element = 30
result = find_index(arr, element)

if result != -1:
    print(f"Element {element} is at index: {result}")
else:
    print(f"Element {element} not found in the array.")
