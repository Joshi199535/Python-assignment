def remove_element(arr, element):
    try:
        arr.remove(element)  # Removes the first occurrence of the element
    except ValueError:
        pass  # Do nothing if the element is not found
    return arr
arr = [10, 20, 30, 40, 50]
element = 30

updated_array = remove_element(arr, element)
print(f"Updated array: {updated_array}")

