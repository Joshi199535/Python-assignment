def copy_array(arr):
    return arr.copy()  # Creates a shallow copy of the array
original_array = [10, 20, 30, 40, 50]
copied_array = copy_array(original_array)

print(f"Original Array: {original_array}")
print(f"Copied Array: {copied_array}")
import copy

def copy_nested_array(arr):
    return copy.deepcopy(arr)


