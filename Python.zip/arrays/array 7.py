def insert_element(arr, element, position):
    arr.insert(position, element)
    return arr
arr = [10, 20, 30, 40, 50]
element = 25
position = 2

updated_array = insert_element(arr, element, position)
print(f"Updated array: {updated_array}")

