def find_min_max(arr):
    if not arr:
        return None, None  # Return None for both if the array is empty
    return min(arr), max(arr)
arr = [10, 20, 30, 40, 50]
min_value, max_value = find_min_max(arr)

print(f"Minimum value: {min_value}")
print(f"Maximum value: {max_value}")

