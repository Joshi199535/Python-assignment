
def reverse_array(arr):
    return arr[::-1]  # Use slicing to reverse the array
arr = [10, 20, 30, 40, 50]
reversed_array = reverse_array(arr)

print(f"Original array: {arr}")
print(f"Reversed array: {reversed_array}")
def reverse_array_in_place(arr):
    arr.reverse()  # Reverse the array in place
    return arr

