class MyClass:
    def __init__(self, arg1=0, arg2=0):
        """
        Constructor with default arguments.
        """
        self.value1 = arg1
        self.value2 = arg2
        if arg1 == 0 and arg2 == 0:
            print("Default constructor called.")
        elif arg1 != 0 and arg2 == 0:
            print("One argument constructor called.")
        else:
            print("Two arguments constructor called.")

if __name__ == "__main__":
    # Call the default constructor
    obj1 = MyClass()

    # Call the one argument constructor
    obj2 = MyClass(10)

    # Call the two arguments constructor
    obj3 = MyClass(20, 30)
