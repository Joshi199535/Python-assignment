# Superclass with two constructors: default and argument-based
class Animal:
    def __init__(self, name=None):
        if name:
            self.name = name
            print(f"Animal created with name: {self.name}")
        else:
            self.name = "Unknown"
            print("Animal created with default name")

# Child class inheriting from Animal
class Dog(Animal):
    def __init__(self, name=None, breed=None):
        # Calling the superclass constructor (both default and argument constructors)
        super().__init__(name)  # Calling the Animal constructor with the name argument
        self.breed = breed
        if breed:
            print(f"Dog created with breed: {self.breed}")
        else:
            print("Dog created with default breed")

# Main program
print("Creating Dog with a name and breed:")
dog1 = Dog(name="Buddy", breed="Golden Retriever")

print("\nCreating Dog with only a name:")
dog2 = Dog(name="Max")

print("\nCreating Dog with no arguments:")
dog3 = Dog()
