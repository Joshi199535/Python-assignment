# Superclass with different access modifiers on the constructor
class Animal:
    def __init__(self, name=None):
        # Public constructor
        self.name = name if name else "Unknown"
        print(f"Animal created with name: {self.name}")

    # Protected constructor
    def _protected_method(self):
        print("This is a protected method.")
    
    # Private constructor
    def __private_method(self):
        print("This is a private method.")
    
    # Default constructor (in Python, we can simulate default constructor via optional arguments)
    def default_method(self):
        print("This is a default (public) method.")

# Subclass that inherits from Animal
class Dog(Animal):
    def __init__(self, name=None, breed=None):
        # Call the public constructor from Animal
        super().__init__(name)
        
        # Private constructor cannot be accessed from outside
        # self.__private_method()  # Uncommenting this will raise an error
        
        # Call the protected method
        self._protected_method()

        self.breed = breed if breed else "Unknown Breed"
        print(f"Dog created with breed: {self.breed}")

# Main program
print("Creating Dog with a name and breed:")
dog1 = Dog(name="Buddy", breed="Golden Retriever")

print("\nAccessing default method from the Animal class:")
dog1.default_method()

# Try to access private and protected methods from outside
# dog1.__private_method()  # This will raise an error because of name mangling

# Protected method can be accessed, but it's not recommended
dog1._protected_method()  # This works, but it's conventionally considered protected
