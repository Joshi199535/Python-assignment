# Class with constructor having attributes
class Person:
    def __init__(self, name, age, city):
        # These are constructor attributes
        self.name = name
        self.age = age
        self.city = city
        print(f"Person object created with name: {self.name}, age: {self.age}, city: {self.city}")

    # Method to display information about the person
    def display_info(self):
        print(f"Name: {self.name}, Age: {self.age}, City: {self.city}")


# Creating objects and passing parameters to the constructor
person1 = Person("Alice", 30, "New York")
person2 = Person("Bob", 25, "Los Angeles")

# Calling the display_info method to print attributes of the objects
person1.display_info()
person2.display_info()
