students = {
    101: "Alice Johnson",
    102: "Bob Smith",
    103: "Charlie Brown",
    104: "Diana Prince",
    105: "Ethan Hunt"
}
print(students)
