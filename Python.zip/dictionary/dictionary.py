# 1.1 Adding values to a dictionary
students = {}
students[101] = "Alice Johnson"
students[102] = "Bob Smith"
print("After adding values:", students)

# 1.2 Updating values in a dictionary
students[101] = "Alice Williams"  # Update Alice's name
print("After updating a value:", students)

# 1.3 Accessing a value in a dictionary
student_name = students.get(101)  # Access using the key
print("Accessed value for ID 101:", student_name)

# 1.4 Create a nested loop dictionary
nested_students = {
    1: {"name": "Alice", "age": 20, "major": "Physics"},
    2: {"name": "Bob", "age": 22, "major": "Mathematics"},
    3: {"name": "Charlie", "age": 21, "major": "Computer Science"}
}
print("Nested dictionary:", nested_students)

# 1.5 Access values of a nested dictionary
charlie_major = nested_students[3]["major"]
print("Charlie's major:", charlie_major)

# 1.6 Print the keys present in a dictionary
keys = students.keys()
print("Keys in the dictionary:", list(keys))

# 1.7 Delete a value from a dictionary
del students[102]  # Delete Bob's record
print("After deleting a value:", students)

