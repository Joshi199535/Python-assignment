def generate_class_not_found_exception():
    try:
        from some_module import NonExistentClass
    except ImportError as e:
        print(f"Error: {e}")
print("Program to generate ClassNotFoundException (ImportError):")
generate_class_not_found_exception()
