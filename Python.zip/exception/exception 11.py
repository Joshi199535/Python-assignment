def generate_io_exception():
    try:
        with open('non_existent_file.txt', 'r') as file:
            content = file.read()
        print(content)
    except IOError as e:
        print(f"Error: {e}")
print("Program to generate IOError (simulated IOException):")
generate_io_exception()
