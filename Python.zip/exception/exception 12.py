class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
def generate_no_such_field_exception():
    person = Person("Alice", 30)
    
    try:
        print(person.address)
    except AttributeError as e:
        print(f"Error: {e}")
print("Program to generate NoSuchFieldException (AttributeError):")
generate_no_such_field_exception()
