def divide_numbers(num1, num2):
    try:
      result = num1 / num2
      return result
    except ZeroDivisionError:
      print("Error: Division by zero is not allowed.")
      return None

if __name__ == "__main__":
  num1 = 10
  num2 = 0
  result = divide_numbers(num1, num2) 
  print("Result:", result) 
