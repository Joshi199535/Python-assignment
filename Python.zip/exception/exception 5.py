def validate_age(age):
    if age < 18:
        raise ValueError("Age must be 18 or older to register.")
    print("Age is valid for registration.")
try:
    user_age = int(input("Enter your age: "))
    validate_age(user_age)
except ValueError as e:
    print(f"Error: {e}")
