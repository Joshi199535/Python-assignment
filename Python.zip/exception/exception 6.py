class AgeValidationError(Exception):
    def __init__(self, message="Age must be 18 or older."):
        self.message = message
        super().__init__(self.message)
def validate_age(age):
    if age < 18:
        raise AgeValidationError("Age is below the required limit!")
    print("Age is valid for registration.")
try:
    user_age = int(input("Enter your age: "))
    validate_age(user_age)
except AgeValidationError as e:
    print(f"Custom Exception: {e}")
