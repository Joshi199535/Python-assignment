def divide_numbers(a, b):
    try:
        result = a / b
        print(f"The result is: {result}")
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
    finally:
        print("Execution of the try-except block is complete.")
try:
    numerator = int(input("Enter numerator: "))
    denominator = int(input("Enter denominator: "))
    divide_numbers(numerator, denominator)
except ValueError:
    print("Error: Invalid input. Please enter numeric values.")
finally:
    print("Program execution has ended.")
