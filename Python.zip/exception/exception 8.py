def generate_arithmetic_exception():
    numerator = 10
    denominator = 0  
    result = numerator / denominator  
    print(f"Result: {result}")
print("Program to generate Arithmetic Exception:")
generate_arithmetic_exception()
