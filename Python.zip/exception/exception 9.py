def generate_file_not_found_exception():
    file_path = "non_existent_file.txt"
    with open(file_path, "r") as file:
        content = file.read()
    print(content)
print("Program to generate FileNotFoundError:")
generate_file_not_found_exception()
