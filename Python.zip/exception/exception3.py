class ExceptionDemo:
    def method_that_throws(self):
        raise ValueError("This is a custom exception!")
if __name__ == "__main__":
    demo = ExceptionDemo()
    demo.method_that_throws()
    
    print("This line will not execute because of the unhandled exception.")

