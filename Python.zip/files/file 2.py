file_path = "output.txt"
try:
    with open(file_path, 'w') as file:
        print("Enter text to write to the file. Type 'STOP' to finish.")
    while True:
        user_input = input(">> ")
        if user_input.upper() == 'STOP':
                print("Writing to the file has been stopped.")
                break
        file.write(user_input + '\n')
    
    print(f"Text has been successfully written to {file_path}.")

except Exception as e:
    print(f"An error occurred: {e}")
            
