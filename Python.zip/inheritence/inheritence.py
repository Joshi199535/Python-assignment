class A:
    def __init__(self):
        self.a = 10

    def method_a1(self):
        print("Method A1 in Class A")

    def method_a2(self):
        print("Method A2 in Class A")

    def overridden_method(self):
        print("Overridden Method in Class A")

class B(A):
    def __init__(self):
        super().__init__()
        self.b = 20

    def method_b1(self):
        print("Method B1 in Class B")

    def method_b2(self):
        print("Method B2 in Class B")

    def overridden_method(self):
        print("Overridden Method in Class B")

class C(B):
    def __init__(self):
        super().__init__()
        self.c = 30

    def method_c1(self):
        print("Method C1 in Class C")

    def method_c2(self):
        print("Method C2 in Class C")

    def overridden_method(self):
        print("Overridden Method in Class C")

if __name__ == "__main__":
    # Create objects
    obj_a = A()
    obj_b = B()
    obj_c = C()

    # Call methods of A
    obj_a.method_a1()
    obj_a.method_a2()
    obj_a.overridden_method()

    # Call methods of B
    obj_b.method_b1()
    obj_b.method_b2()
    obj_b.overridden_method()

    # Call methods of C
    obj_c.method_c1()
    obj_c.method_c2()
    obj_c.overridden_method()

    # Call overridden method with superclass reference
    a_ref_b = A() 
    a_ref_b = obj_b 
    a_ref_b.overridden_method()  # Calls overridden_method() of Class B

    a_ref_c = A() 
    a_ref_c = obj_c 
    a_ref_c.overridden_method()  # Calls overridden_method() of Class C

    # Runtime Polymorphism with Data Members
    print("Data Members:")
    print(f"Object A: a = {obj_a.a}")
    print(f"Object B: a = {obj_b.a}, b = {obj_b.b}")
    print(f"Object C: a = {obj_c.a}, b = {obj_c.b}, c = {obj_c.c}") 

    # Accessing data members using superclass reference
    print("Accessing data members using superclass reference:")
    a_ref_b = A() 
    a_ref_b = obj_b 
    print(f"a_ref_b.a: {a_ref_b.a}")  # Accesses 'a' from Class B

    a_ref_c = A() 
    a_ref_c = obj_c 
    print(f"a_ref_c.a: {a_ref_c.a}")  # Accesses 'a' from Class C
