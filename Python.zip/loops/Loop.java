package myPackage;

public class Loop {
	public static void main(String[] args) {
        int i = 1; // Initialize the counter

        while (i <= 20) { // Condition for the loop to continue
            System.out.println(i); // Print the current value of i
            i++; // Increment i for the next iteration
        }
    }

}
