for i in range(10):
    print("Bright IT Career")
