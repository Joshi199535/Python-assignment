def is_palindrome(value):
    value_str = str(value)
    if value_str == value_str[::-1]:
        return True
    else:
        return False
value = input("Enter a number or string: ")
if is_palindrome(value):
    print(f"{value} is a palindrome.")
else:
    print(f"{value} is not a palindrome.")
