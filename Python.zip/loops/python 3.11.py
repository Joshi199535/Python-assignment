def check_even_odd(number):
    match number % 2:
        case 0:
            return "Even"
        case 1:
            return "Odd"
num = int(input("Enter a number: "))
result = check_even_odd(num)
print(f"{num} is {result}.")
