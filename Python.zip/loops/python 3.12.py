def print_gender(gender_code):
    match gender_code.upper():
        case 'M':
            return "Male"
        case 'F':
            return "Female"
        case _:
            return "Invalid input"
gender_code = input("Enter gender code (M/F):")
result = print_gender(gender_code)
print(f"Gender: {result}")
