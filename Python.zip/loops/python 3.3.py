x = 5
y = 5
z = 10
print(x == y) #True
print(x == z) #False
print(x != y) #False
print(x != z) #True
