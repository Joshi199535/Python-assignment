def print_odd_even(numbers):
    print("Even numbers:")
    for num in numbers:
        if num % 2 == 0:
            print(num)

    print("\nOdd numbers:")
    for num in numbers:
        if num % 2 != 0:
            print(num)

my_numbers = [1,2,3,4,5,6,7,8,9,10]
print_odd_even(my_numbers)
                
