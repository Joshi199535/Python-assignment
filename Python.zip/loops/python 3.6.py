number = 10
while number <= 20:
    if number % 2 == 0:
        print(number)
    number += 1
