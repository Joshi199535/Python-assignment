number = 1
while True:
    print(number)
    number += 1
    if number > 10:
        break
