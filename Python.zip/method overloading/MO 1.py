class Calculator:
    def add(self, a, b=0):
        return a + b
calculator = Calculator()
result1 = calculator.add(5)
print(f"Result of add(5): {result1}")
result2 = calculator.add(5, 10)
print(f"Result of add(5, 10): {result2}")
