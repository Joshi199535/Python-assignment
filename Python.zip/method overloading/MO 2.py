def my_method(x: int, y: int) -> int:
    """
    Adds two integers.

    Args:
        x: The first integer.
        y: The second integer.

    Returns:
        The sum of x and y.
    """
    return x + y

def my_method(x: str, y: str) -> str:
    """
    Concatenates two strings.

    Args:
        x: The first string.
        y: The second string.

    Returns:
        The concatenation of x and y.
    """
    return x + y

# Calling the methods:
result1 = my_method(5, 3)  # Calls the first my_method (integer addition)
print(result1)  # Output: 8

result2 = my_method("Hello", " world!")  # Calls the second my_method (string concatenation)
print(result2)  # Output: Hello world!

            

