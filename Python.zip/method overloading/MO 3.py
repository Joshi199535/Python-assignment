def my_method(x: int, y: int) -> int:
    """
    Adds two integers.

    Args:
        x: The first integer.
        y: The second integer.

    Returns:
        The sum of x and y.
    """
    return x + y

def my_method(x: int, y: int) -> str:
    """
    Concatenates the string representations of two integers.

    Args:
        x: The first integer.
        y: The second integer.

    Returns:
        The concatenation of the string representations of x and y.
    """
    return str(x) + str(y)

# Calling the methods (This will result in an error)
result1 = my_method(5, 3)  
print(result1)
