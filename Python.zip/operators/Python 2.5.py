def find_smaller_larger(num1, num2):
    if num1 < num2:
        return num1, num2
    else:
        return num2, num1
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
smaller, larger = find_smaller_larger(num1, num2)

print("Smallest number:", smaller)
print("Largest number:", larger)
