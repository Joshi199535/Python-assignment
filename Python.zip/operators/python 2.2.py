def increment(x):
    return x + 1
def decrement(x):
    return x - 1

x = 5
print("Initial value of x:", x)

x = increment(x)
print("After increment:", x)

x = decrement(x)
print("After decrement:", x)
 
