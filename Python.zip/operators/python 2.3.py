def are_numbers_equal(num1, num2):
    return num1 == num2
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))
if are_numbers_equal(num1, num2):
    print("The numbers are qual.")
else:
    print("The numbers are not equal.")
