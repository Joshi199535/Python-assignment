# Python program to demonstrate relational operators

# Taking two input numbers from the user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Using relational operators to compare the two numbers
print(f"{num1} < {num2}: {num1 < num2}")
print(f"{num1} <= {num2}: {num1 <= num2}")
print(f"{num1} > {num2}: {num1 > num2}")
print(f"{num1} >= {num2}: {num1 >= num2}")

    
    
