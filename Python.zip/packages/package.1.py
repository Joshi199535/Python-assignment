class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def introduce(self):
        print(f"Hi, I'm {self.name} and I'm {self.age} years old.")
class Student(Person):
    def __init__(self, name, age, student_id):
        super().__init__(name, age)
        self.student_id = student_id
    def study(self):
        print(f"{self.name} is studying. Student ID: {self.student_id}")
son = Person("Alice", 30)
son.introduce()
dent = Student("Bob", 20, "S12345")
dent.introduce()
dent.study()

        
