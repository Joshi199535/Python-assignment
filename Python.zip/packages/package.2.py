class Car:
    def __init__(self, make, model):
        self.make = make
        self.model = model
    def display_info(self):
        print(f"This car is a {self.make} {self.model}.")
class Owner:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def introduce(self):
        print(f"Hi, I'm {self.name} and I'm {self.age} years ild.")
car = Car("Toyota", "Corolla")
car.display_info()
owner = Owner("Alice", 35)
owner.introduce()
