import os
package_name = "mypackage"
modules = ["module1", "module2", "module3"]
os.makedirs(package_name, exist_ok=True)
init_file_path = os.path.join(package_name, "__init__.py")
with open(init_file_path, "w") as f:
    for module in modules:
        f.write(f"from. {module} import *\n")
print(f"__init__.py created successfully in {package_name}/")
