import math
radius = 5
area = math.pi * (radius ** 2)
print(f"The area of a circle with radius {radius} is {area:.2f}")
