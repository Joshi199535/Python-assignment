class Animal:
    def __init__(self, name):
        self.name = name
    def speak(self):
        print(f"{self.name} make a sound.")
class Dog(Animal):
    def __init__(self, name, breed):
        super().__init__(name)
        self.breed = breed
    def speak(self):
        print(f"{self.name} barks.")
class Cat(Animal):
    def __init__(self, name, color):
        super().__init__(name)
        self.color = color
    def speak(self):
        print(f"{self.name} meows.")
animal = Animal("Generic Animal")
dog = Dog("Buddy", "Golden Retriver")
cat = Cat("Whiskers", "Tabby")
animal.speak()
dog.speak()
cat.speak()
        
