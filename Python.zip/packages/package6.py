import math
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        print(f"{self.name} makes a sound.")

class Dog(Animal):
    def __init__(self, name, breed):
        super().__init__(name)
        self.breed = breed

    def speak(self):
        print(f"{self.name} barks.")

class Cat(Animal):
    def __init__(self, name, color):
        super().__init__(name)
        self.color = color

    def speak(self):
        print(f"{self.name} meows.")
radius = 5
area = math.pi * (radius ** 2)

print(f"The area of a circle with radius {radius} is {area:.2f}")
animal = Animal("Generic Animal")
dog = Dog("Buddy", "Golden Retriever")
cat = Cat("Whiskers", "Tabby")
animal.speak()  # Calls speak method of Animal
dog.speak()     # Calls speak method of Dog
cat.speak() 
