# This is a single-line comment

"""
This is a
multi-line
comment.
"""
print("This line will be executed.")
