def print_name():
    print("Jyoshi Shruthi")
if __name__ == "__main__":
    print_name()
