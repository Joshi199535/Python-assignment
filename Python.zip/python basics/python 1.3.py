my_int = 5
my_float = 4.25
my_char = 'Jyoshi'
my_bool = True

print("Integer:", my_int)
print("Float:", my_float)
print("Character:", my_char)
print("Boolean:", my_bool)
