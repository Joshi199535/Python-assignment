def my_function():
    global global_var
    global_var = 30

global_var = 10

def my_function():
    local_var = 20

    print("Inside the fuction:")
    print("Local variable:", local_var)
    print("Global variable:", global_var)

print("\nOutside the function:")
print("Global variable:", global_var)

my_function()

    
