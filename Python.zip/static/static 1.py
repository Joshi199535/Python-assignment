class MyClass:
    static_variable = "I am a static variable"
    def display_static_variable(self):
        print(f"Accessed via instance: {MyClass.static_variable}")

    @classmethod
    def display_static_variable_classmethod(cls):
        print(f"Accessed via class method: {cls.static_variable}")
print(MyClass.static_variable)
obj = MyClass()
obj.display_static_variable()
obj.display_static_variable_classmethod()
    
