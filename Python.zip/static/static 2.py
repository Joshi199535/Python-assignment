class MyClass:
    static_variable = "I am a static variable"
    def access_static_variable(self):
        print(f"Accessed through instance: {self.static_variable}")
instance = MyClass()
instance.access_static_variable()
MyClass.static_variable = "I am modified static variable"
instance.access_static_variable()
