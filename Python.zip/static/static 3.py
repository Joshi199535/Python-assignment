class MyClass:
    static_variable = "I am a static variable"
    def modify_static_variable(self, new_value):
        MyClass.static_variable = new_value
        print(f"Static variable modified to: {MyClass.static_variable}")
    def display_static_variable(self):
        print(f"Current static variable value: {MyClass.static_variable}")
instance1 = MyClass()
instance1.display_static_variable()
instance1.modify_static_variable("Static variable has been changed")
instance2 = MyClass()
instance2.display_static_variable()
        
