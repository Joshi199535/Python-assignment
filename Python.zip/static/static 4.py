class MyClass:
    static_variable = "I am a static variable"
    @classmethod
    def modify_static_variable(cls, new_value):
        cls.static_variable = new_value
        print(f"Static variable modified to: {cls.static_variable}")
print(f"Initial static variable: {MyClass.static_variable}")
MyClass.modify_static_variable("I ama amodified static variable")
print(f"Updated static variable: {MyClass.static_variable}")
